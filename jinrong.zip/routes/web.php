<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//前台首页
Route::get('/','home\IndexController@index');
//微信授权
Route::get('users','home\UserController@users');
Route::get('user/{openId}','home\UserController@user');
Route::group(['Middleware'=>'AdminLogin'],function(){
	//后台首页
	Route::get('admin/index','admin\IndexController@index');
	//后台用户
	Route::resource('admin/user','admin\UserController');
	Route::get('admin/banka','admin\BankaController@index');
	Route::get('admin/cash','admin\CashController@index');
	Route::get('admin/order','admin\OrderController@index');
	Route::get('admin/system','admin\SystemController@system');
	Route::resource('admin/service','admin\ServiceController');

	Route::resource('admin/group','admin\GroupController');
	Route::resource('admin/fcategory','admin\FcategoryController');
	Route::resource('admin/auth','admin\AdminController');
	Route::resource('admin/ad','admin\AdController');
	Route::resource('admin/user','admin\UserController');
	Route::resource('admin/bank','admin\BanksController');	
	Route::any('admin/bankdel','admin\BanksController@bankdel');	
	Route::resource('admin/article','admin\ArticleController');
	Route::resource('admin/notice','admin\NoticeController');

// 新闻分类管理
Route::resource('admin/newcate','admin\NewcateController');

Route::resource('admin/fcategory','admin\FcategoryController');
});
Route::post('tupian','admin\AjaxController@tupianajax');
Route::any('admin/dologin','admin\LoginController@dologin');
Route::any('admin/login','admin\LoginController@login');
Route::any('admin/logout','admin\LoginController@logout');
