@extends('common.admin')
@section('content')
<blockquote class="layui-elem-quote f18">{{$title}}</blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            用户级别
                        </th>
                        <th>
                            升级费用
                        </th>
                        <th>
                            阅读权重
                        </th>
                        <th>
                            排序
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                @foreach ($res as $res)
                <tbody>
                    <tr>
                        <td>
                            {{$res->id}}
                        </td>
                        <td>
                            {{$res->name}}
                        </td>
                        <td >
                            {{$res->price}}
                        </td>
                        <td >
                            {{$res->weight}}
                        </td>
                        <td >
                            {{$res->sort}}
                        </td>
                    <td>
                         <a href="/admin/group/{{$res->id}}/edit" class="layui-btn layui-btn-sm ">编辑</a>
                        <form action="/admin/group/{{$res->id}}" method='post' style='display:inline'>
                          {{csrf_field()}}

                          {{method_field('DELETE')}}
                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
<!-- 右侧主体结束 -->
 @endsection

@section('js')
<script>
   /*用户-添加*/
    function member_add(title,url,w,h)
    {
        x_admin_show(title,url,w,h);
    }
    /*用户-编辑*/
  function member_edit (title,url,id,w,h) 
  {
     x_admin_show(title,url,w,h); 
  }
</script>
@endsection