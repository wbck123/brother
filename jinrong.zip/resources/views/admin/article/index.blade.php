@extends('common.admin')

@section('content')

<blockquote class="layui-elem-quote f18">{{$title}}</blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                         <th>
                            新闻分类
                        </th>
                        <th>
                            新闻标题
                        </th>
                       
                        <th>
                            新闻封面
                        </th>
                        <th>
                            创建时间
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>

                </thead>
                @foreach($res as $k => $v)
                <tbody>
                    <tr>
                        <td >
                            {{$v->id}}
                        </td>
                        <td >
                            {{$v->title}}
                        </td>
                        
                        <td>
                            {{$v->sort}}
                        </td>
                        <th>
                            <img src="{{$v->pic}}" width="100px">
                        </th>
                        <th>
                           <?php
                              echo date('Y-m-d',$v->ctime);
                           ?>
                        </th>
                        <td>
                         <a href="/admin/article/{{$v->id}}/edit" class="layui-btn layui-btn-sm ">编辑</a>
                        <form action="/admin/article/{{$v->id}}" method='post' style='display:inline'>
                          {{csrf_field()}}

                          {{method_field('DELETE')}}
                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                    </tr>
                </tbody>
                @endforeach
            </table>
          </div>
        </div>
@endsection