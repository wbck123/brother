@extends('common.admin')
@section('content')
<blockquote class="layui-elem-quote f18">{{$title}}</blockquote>
        <div class="page-content">
          <div class="content">
            <form action="/admin/bank" method='post' class="mws-form" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        银行名称
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_email" name="name" required lay-verify="name" placeholder="请输入银行名称"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        返佣价格
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="price" required lay-verify="required|number" placeholder="请输入返佣价格"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        银行图标
                    </label>
                    <div class="uploader red">
                        <input type="file" class="filename" name="bpic" />
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        查询网址
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="burl" required lay-verify="required|url" placeholder="请输入查询网址"
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                       <p style="color: red">* 办卡进度查询网址 格式为http://</p>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        排序
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="sort" required lay-verify="required|number" placeholder="请输入排列序号"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_sign" class="layui-form-label">
                    </label>
                    <button class="layui-btn" key="set-mine" lay-filter="save" lay-submit id="bankadd">
                        添加
                    </button>
                </div>
            </form>
          </div>
        </div>
<script>
layui.use('form', function(){
  var form = layui.form;
  form.render();
}); 
layui.use(['jquery'], function(){
  var $ = jQuery = layui.$;
  
  $('#bankadd').on('click',function(){
    var price = $('input[name=price]').val();
    var bpic = $('input[name=bpic]').val();
    var url = $('input[name=burl]').val();
    var sort = $('input[name=sort]').val();

      var priceReg = /^\d{1,20}$/;
      if(!priceReg.test(price)){
        layer.msg('返佣价格格式不正确');
        return false;
      }

      var urlReg = /(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
      if(!urlReg.test(url)){
        layer.msg('查询网址格式不正确');
        return false;
      }

       var sortReg = /^\w{1,12}$/;
      if(!sortReg.test(sort)){
        layer.msg('排序格式不正确');
        return false;
      }
});  

});  
</script>
@endsection