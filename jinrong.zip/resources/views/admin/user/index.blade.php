@extends('common.admin')
@section('content')
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/admins/js/xadmin.js"></script>
<blockquote class="layui-elem-quote f18">{{$title}}</blockquote>
        <div class="page-content">
          <div class="content">
            <form class="layui-form xbs" action="/admin/user" method="get">
                <div class="layui-form-pane" style="text-align: center;">
                  <div class="layui-form-item" style="display: inline-block;">
                  	<div class="layui-input-inline">
                      <input type="text" name="tel"  placeholder="手机号查询" value="{{$request->tel}}" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-input-inline">
                      <input type="text" name="name"  placeholder="姓名查询" value="{{$request->name}}" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-input-inline" style="width:80px">
                        <button class="layui-btn"  lay-submit="" lay-filter="sreach"><i class="layui-icon">&#xe615;</i></button>
                    </div>
                  </div>
                </div> 
            </form>
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            编号
                        </th>
                        <th>
                            姓名
                        </th>
                        <th>
                            会员ID
                        </th>
                        <th>
                            头像
                        </th>
                        <th>
                           手机号
                        </th>
                        <th>
                            身份证号码
                        </th>
                        <th>
                            第一级
                        </th>
                        <th>
                            第二级
                        </th>
                        <th>
                            第三级
                        </th>
                        <th>
                            用户级别
                        </th>
                        <th>
                            余额
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                @foreach($res as $res)
                <tbody>
                    <tr>
                        <td >
                            {{$res->id}}
                        </td>
                        <td>
                             <u style="cursor:pointer" onclick="member_show('{{$res->nick}}详情','/admin/user/{{$res->id}}','600','600')">
                            {{$res->nick}}
                            </u>
                        </td>
                        <td >
                            {{$res->vid}}
                        </td>
                        <td >
                        <img src="{{$res->tpic}}" alt="">
                        </td>
                        <td >
                            {{$res->tel}}
                        </td>
                        <td >
                            {{$res->card}}
                        </td>
                        <td >
                            {{$res->lev1}}
                        </td>
                        <td >
                            {{$res->lev2}}
                        </td>
                        <td>
                            {{$res->lev3}}
                        </td>
                        <td>
                            用户级别
                        </td>
                        <td>
                            {{$res->money}}元
                        </td>
                    <td>
                        <form action="/admin/user/{{$res->id}}" method='post' style='display:inline'>
                          {{csrf_field()}}

                          {{method_field('DELETE')}}
                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>

 @endsection

 @section('js')
<script>
   /*用户-展示*/
  function member_show(title,url,id,w,h)
  {
     x_admin_show(title,url,w,h);
   }
</script>
 @endsection
