@extends('common.admin')
@section('content')
<blockquote class="layui-elem-quote f18">{{$title}}</blockquote>
<div class="table-responsive">
            <table class="layui-table table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>姓名</th>
                    <th>手机号码</th>
                    <th>创建时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody id="con">
                  @foreach($res as $res)
                 <tr>
                    <td>{{$res->id}}</td>
                    <td>{{$res->name}}</td>
                    <td>{{$res->tel}}</td>
                    <td>{{date('Y-m-d',$res->ctime)}}</td>
                    <td>
                      @if ($res->status == 0)
                       <button class="layui-btn layui-btn-sm" id="status">已启用</button>
                      @else
                      <button class="layui-btn layui-btn-sm layui-btn-danger" id="status">已禁用</button>
                      @endif
                    </td>
                    <td>
                      <a href="/admin/auth/{{$res->id}}/edit" class="layui-btn layui-btn-sm ">编辑</a>

                  <form action="/admin/auth/{{$res->id}}" method='post' style='display:inline'>
                                {{csrf_field()}}

                                {{method_field('DELETE')}}
                                <button class="layui-btn layui-btn-sm layui-btn-danger" id="shanchu">删除</button>
                            </form>
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
<script>
layui.use(['jquery', 'layer'], function(){ 
  var $ = layui.$ //重点处
  ,layer = layui.layer;
  
  //后面就跟你平时使用jQuery一样
  $('status').on('click',function(){
      alert('1111');
  });
});

</script>
 @endsection

