@extends('common.admin')
@section('content')
<blockquote class="layui-elem-quote f18">{{$title}}</blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            公告标题
                        </th>
                        <th>
                            排序
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                @foreach ($res as $res)
                <tbody>
                    <tr>
                        <td>
                            {{$res->id}}
                        </td>
                        <td>
                            {{$res->title}}
                        </td>
                        <td >
                            {{$res->sort}}
                        </td>
                    <td>
                         <a href="/admin/notice/{{$res->id}}/edit" class="layui-btn layui-btn-sm ">编辑</a>
                        <form action="/admin/notice/{{$res->id}}" method='post' style='display:inline'>
                          {{csrf_field()}}

                          {{method_field('DELETE')}}
                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
<!-- 右侧主体结束 -->
 @endsection
