
<!DOCTYPE html>
<html>
<head lang="en"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no, email=no">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="HandheldFriendly" content="true">
<meta name="MobileOptimized" content="640">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="msapplication-tap-highlight" content="no">
<meta name="viewport" content="width=640,target-densitydpi=device-dpi,maximum-scale=1.0, user-scalable=no ">
<meta name="keywords" content="金融行业">
<meta name="description" content="金融行业">
<title>金融行业</title>
<link rel="stylesheet" href="/home/css/common.css" type="text/css">
<link rel="stylesheet" href="/home/css/font-awesome.min.css">
<link rel="stylesheet" href="/home/css/swiper.min.css" type="text/css">
<script src="/home/js/jquery-2.1.3.min.js" type="text/javascript"></script>
<script src="/home/js/common.js" type="text/javascript"></script>
<script src="/home/js/Validform_min.js"></script>
<script src="/home/js/infinite-scroll.pkgd.min.js"></script>
<script src="/home/js/swiper.min.js"></script>
<body>
<div class="loading" id="loading">
	<div class="spinner">
		<div class="spinner-container container1">
			<div class="circle1"></div>
			<div class="circle2"></div>
			<div class="circle3"></div>
			<div class="circle4"></div>
		</div>
		<div class="spinner-container container2">
			<div class="circle1"></div>
			<div class="circle2"></div>
			<div class="circle3"></div>
			<div class="circle4"></div>
		</div>
		<div class="spinner-container container3">
			<div class="circle1"></div>
			<div class="circle2"></div>
			<div class="circle3"></div>
			<div class="circle4"></div>
		</div>
	</div>
	<p>加载中...</p>
</div>
<div class="alert" id="salert">
	<div class="alert-bg"></div>
	<div class="alert-box">
		<div class="msg">
			
		</div>
		<div class="btns">
			<a href="javascript:$('#salert').hide();" id="salert-false">取消</a>
			<a href="javascript:;" id="salert-true">确定</a>
		</div>
	</div>
</div>

	<div class="banner">
		<style>
			
		</style>
		<div id="focus" class="focus">
			<div class="hd">
				<ul></ul>
			</div>
			<div class="bd">
				<ul>
					<li>
						<a href="/"><img src="/uploads/ad1.png" /></a>
					</li>
					<li>
						<a href="/"><img src="/uploads/ad2.png" /></a>
					</li>
					<li>
						<a href="/"><img src="/uploads/ad1.png" /></a>
					</li>

				</ul>
			</div>
		</div>
		<script src="/home/js/TouchSlide.1.1.js"></script>
		<script type="text/javascript">
			TouchSlide({ 
				slideCell:"#focus",
				titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
				mainCell:".bd ul", 
				effect:"left", 
				autoPlay:true,//自动播放
				autoPage:true, //自动分页
				switchLoad:"_src" //切换加载，真实图片路径为"_src" 
			});
		</script>
	</div>

	@section('content')

	@show

<a class="scroll_top" href="javascript:window.scrollTo('0','0');" style="display: none;">top</a>
<script>
	$(window).scroll(function(){
		if($(window).scrollTop()>300){
			$(".scroll_top").show();
			
		}else{
			$(".scroll_top").hide();
		}
	});
	window.shareData = {
		img: "http://www.ppxlm666.com/Public/upload/images/1805/04/054145567490009258.png", 
		link: "http://www.ppxlm666.com/index.php?m=&c=Index&a=index&ad=1",
		title: "皮皮侠分享内容，可以后台自定义编辑~",
		desc: "欢迎关注皮皮侠，更多精彩内容敬请关注后了解更多哟~~",
	};	
</script>
	<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
	<script>
	wx.config({
		debug: false,
		appId: "wx394aeab031756055",
		timestamp: 1530017394,
		nonceStr: '930xclc5dbbi70cvjypj1pdgxupzd6m5',
		signature: 'f91711e288f72c11e884f1d6d12e1a71ce9d0f87',
		jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage']
	});
	wx.ready(function () {
		wx.checkJsApi({
			jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
			success: function(res) {
				//alert(JSON.stringify(res));
			}
		});
		wx.error(function(res){
			console.log('err:'+JSON.stringify(res));
			// config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。

		});
		//分享给朋友
		wx.onMenuShareAppMessage({
			title: window.shareData.title, // 分享标题
			desc: window.shareData.desc, // 分享描述
			link: window.shareData.link, // 分享链接
			imgUrl: window.shareData.img, // 分享图标
			type: 'link', // 分享类型,music、video或link，不填默认为link
			dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
			success: function () { 
			},
			cancel: function () { 
				
			}
		});
		//分享到朋友圈
		wx.onMenuShareTimeline({
			title: window.shareData.title, // 分享标题
			link: window.shareData.link, // 分享链接
			imgUrl: window.shareData.img, // 分享图标
			success: function () { 
				// 用户确认分享后执行的回调函数
			},
			cancel: function () { 
				// 用户取消分享后执行的回调函数
			}
		});
	});
	</script>
</body>
</html>