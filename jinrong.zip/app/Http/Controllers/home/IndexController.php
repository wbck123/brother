<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
	//首页展示
    public function index()
    {
    	return view('home.index.index');
    }

    public function wechat()
    {
    	echo '111';
    }
}
