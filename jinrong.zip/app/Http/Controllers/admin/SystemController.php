<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class SystemController extends Controller
{
    //网站设置
    public function system()
    {
    	$res = DB::table('system')->first();
        if($res == ''){
            $res = DB::table('system')->insert(['id'=>1]);
        }
   		return view('admin.system.index',['res'=>$res,'title'=>'网站设置']);
    }

    public function dosystem(Request $request,$id)
    {
    	echo $id;
    }

    public function sysAjax()
    {
        echo 1;
    }
}
