<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BankaController extends Controller
{
    public function index()
    {
    	return view('admin.jilu.banka',['title'=>'办卡记录管理']);
    }
}
