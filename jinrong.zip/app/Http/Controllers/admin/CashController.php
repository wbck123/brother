<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CashController extends Controller
{
    public function index()
    {
    	return view('admin.jilu.cash',['title'=>'提现管理']);
    }
}
