//加载显示和隐藏
function loading(flag){
	if(flag){
		$('#loading').show();
	}else{
		$('#loading').hide();
	}
}

//上传图片
function upload(obj){
	//上传图片至服务器
	var img = $(obj.parentElement).find('img');
	var hid = $(obj.parentElement).find('input[type="hidden"]');
	var span = $(obj.parentElement).find('span');
	
	//上传完添加的上传
	var html = $(obj.parentElement).clone();
	var part = $(obj.parentElement.parentElement);
	lrz(obj.files[0], {
		done: function (results) {
			 loading(true);
			  // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
			  $.post("./index.php?m=&c=Index&a=upload_64",
					  {img:results.base64,size:results.base64.length},function(data){
				  if(data.status){
					  loading(false);
					  hid.val(data.info);
					  img.attr('src',data.info);
					  span.addClass('delete');
					  part.append(html);
				  }else{
					  loading(false);
					  salert(data.info);
				  }
			  });
		}
	});	
}


/*
*公共方法Ajax=post提交数据
*url:提交地址，data:数据对象
*/
function Ajax_query(url,data){
	if(!data){
		data = $('form').serialize();
	}
	if(data && url){
		loading(true);
		$.post(url,data,function(d){
			console.log(d);
			if(d){
				loading(false);
				if(d.status){
					salert(d.info,'',function(){
						location.href=d.url
					});
				}else{
					salert(d.info,'','');
				}
			}else{
				loading(false);
				salert('请求失败!','','')
			}
		});
	}
}

/*
*提示框
*content:提示信息,url:跳转地址,flge:是否显示询问键
*/
function salert(content="",flag=false,func=false){
	$('#salert-false').hide();
	$('#salert').find('.msg').html(content);
	$('#salert').show();
	if(flag){
		$('#salert-false').show();
	}
	$('#salert-true').click(function(){
		if(func){
			func();
		}else{
			$('#salert').hide();
		}
	})
	
}


/*
*注册发送验证码
*ob:发送按钮元素
*/
var flag = true;
function sendSms(ob,$type){
	if(flag){
		var mobile = $('#mobile').val();
		if(checkMobile(mobile)){
			$.post("./index.php?m=&c=Public&a=SendSms",{mobile:mobile,type:$type},function(d){
				if(d){
					if(d.status){
						salert(d.info,'','');
						Settime(ob);
					}else{
						loading(false);
						salert(d.info,'','');
					}
				}else{
					loading(true);
					salert('请求失败！','','');
				}
			});
		}
	}
}



//验证码倒计时
var countdown = 60;
function Settime(ob) {
    if (countdown == 0) {
        $(ob).html("获取验证码");
        countdown = 60;
		flag = true;
		$(ob).css('background','#3679ff');
        return;
    } else {
        $(ob).html(countdown+'S');
		$(ob).css('background','#9E9E9E');
        countdown--;
		flag = false;
    }
    setTimeout(function () {
        Settime(ob);
    }, 1000);
}

//校验手机号
function checkMobile(mobile){
	var msg='';
	var myreg = /^1[34578]\d{9}$/;             
	if(mobile == ''){
		msg = '请输入您的手机号！';
	}else if(mobile.length !=11){
		msg = '您的手机号输入有误！';
	}else if(!myreg.test(mobile)){
		msg = '请输入有效的手机号！';
	}
	if(msg!=''){
		salert(msg,'','');
		loading(false);
		return false;
	}else{
		return true;
	}
}

//身份证验证
function checkCardNo(card) { 
	var msg = "";
 	var pattern = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/; 
	if(card.length  == 0){
		msg = "请输入身份证号！";
	}else{
		if(pattern.test(card) == false){
			msg = "身份证号错误";
		}
	}
 	if(msg!=''){
		salert(msg,'','');
		return false;
	}else{
		return true;
	}
} 


//申请产品
function checkIsreply(clid,isReply){
	if(isReply == "" || isReply == "0"){
		$('#reply').show();
	}else{
		var data = {clid:clid,"type":$('input[name="type"]').val()};
		loading(true);
		$.post("./index.php?a=Reply",data,function(d){
			console.log(d);
			if(d){
				loading(false);
				if(d.status){
					if(d.url){
						location.href = d.url;
					}else{
						salert(d.info,'','');
					}
				}else{
					salert(d.info,'','');
				}
			}else{
				salert('请求失败!')
			}
		});
	}
}


