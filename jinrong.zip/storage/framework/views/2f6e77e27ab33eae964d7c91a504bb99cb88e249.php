<?php $__env->startSection('content'); ?>

        <div class="page-content">
          <div class="content">
   <blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>名称</th>
                        <th>图片</th>
                        <th>排序</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
<?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td ><?php echo e($v->id); ?></td>
                        <td ><?php echo e($v->title); ?></td>
                        <td ><img src="<?php echo e($v->pic); ?>" style="height: 50px"></td>
                        <td ><?php echo e($v->sort); ?></td>

                    <td>
                      <a href="/admin/ad/<?php echo e($v->id); ?>/edit" class="layui-btn layui-btn-sm ">编辑</a>

                  <form action="/admin/ad/<?php echo e($v->id); ?>" method='post' style='display:inline'>
                                <?php echo e(csrf_field()); ?>


                                <?php echo e(method_field('DELETE')); ?>

                                <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                            </form>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>