<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
<div class="table-responsive">
            <table class="layui-table table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>姓名</th>
                    <th>手机号码</th>
                    <th>创建时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody id="con">
                  <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($res->id); ?></td>
                    <td><?php echo e($res->name); ?></td>
                    <td><?php echo e($res->tel); ?></td>
                    <td><?php echo e(date('Y-m-d',$res->ctime)); ?></td>
                    <td>
                      <?php if($res->status == 0): ?>
                       <button class="layui-btn layui-btn-sm" id="status">已启用</button>
                      <?php else: ?>
                      <button class="layui-btn layui-btn-sm layui-btn-danger" id="status">已禁用</button>
                      <?php endif; ?>
                    </td>
                    <td>
                      <a href="/admin/auth/<?php echo e($res->id); ?>/edit" class="layui-btn layui-btn-sm ">编辑</a>

                  <form action="/admin/auth/<?php echo e($res->id); ?>" method='post' style='display:inline'>
                                <?php echo e(csrf_field()); ?>


                                <?php echo e(method_field('DELETE')); ?>

                                <button class="layui-btn layui-btn-sm layui-btn-danger" id="shanchu">删除</button>
                            </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
<script>
layui.use(['jquery', 'layer'], function(){ 
  var $ = layui.$ //重点处
  ,layer = layui.layer;
  
  //后面就跟你平时使用jQuery一样
  $('status').on('click',function(){
      alert('1111');
  });
});

</script>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>