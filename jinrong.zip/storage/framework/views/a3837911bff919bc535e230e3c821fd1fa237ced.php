<?php $__env->startSection('content'); ?>
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/admins/js/xadmin.js"></script>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <form class="layui-form xbs" action="/admin/user" method="get">
                <div class="layui-form-pane" style="text-align: center;">
                  <div class="layui-form-item" style="display: inline-block;">
                  	<div class="layui-input-inline">
                      <input type="text" name="tel"  placeholder="手机号查询" value="<?php echo e($request->tel); ?>" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-input-inline">
                      <input type="text" name="name"  placeholder="姓名查询" value="<?php echo e($request->name); ?>" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-input-inline" style="width:80px">
                        <button class="layui-btn"  lay-submit="" lay-filter="sreach"><i class="layui-icon">&#xe615;</i></button>
                    </div>
                  </div>
                </div> 
            </form>
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            编号
                        </th>
                        <th>
                            姓名
                        </th>
                        <th>
                            会员ID
                        </th>
                        <th>
                            头像
                        </th>
                        <th>
                           手机号
                        </th>
                        <th>
                            身份证号码
                        </th>
                        <th>
                            第一级
                        </th>
                        <th>
                            第二级
                        </th>
                        <th>
                            第三级
                        </th>
                        <th>
                            用户级别
                        </th>
                        <th>
                            余额
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td >
                            <?php echo e($res->id); ?>

                        </td>
                        <td>
                             <u style="cursor:pointer" onclick="member_show('<?php echo e($res->nick); ?>详情','/admin/user/<?php echo e($res->id); ?>','600','600')">
                            <?php echo e($res->nick); ?>

                            </u>
                        </td>
                        <td >
                            <?php echo e($res->vid); ?>

                        </td>
                        <td >
                        <img src="<?php echo e($res->tpic); ?>" alt="">
                        </td>
                        <td >
                            <?php echo e($res->tel); ?>

                        </td>
                        <td >
                            <?php echo e($res->card); ?>

                        </td>
                        <td >
                            <?php echo e($res->lev1); ?>

                        </td>
                        <td >
                            <?php echo e($res->lev2); ?>

                        </td>
                        <td>
                            <?php echo e($res->lev3); ?>

                        </td>
                        <td>
                            用户级别
                        </td>
                        <td>
                            <?php echo e($res->money); ?>元
                        </td>
                    <td>
                        <form action="/admin/user/<?php echo e($res->id); ?>" method='post' style='display:inline'>
                          <?php echo e(csrf_field()); ?>


                          <?php echo e(method_field('DELETE')); ?>

                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('js'); ?>
<script>
   /*用户-展示*/
  function member_show(title,url,id,w,h)
  {
     x_admin_show(title,url,w,h);
   }
</script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>