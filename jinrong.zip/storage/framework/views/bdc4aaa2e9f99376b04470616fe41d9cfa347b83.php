<?php $__env->startSection('content'); ?>
        <div class="page-content">
          <div class="content">
            <?php if(count($errors) > 0): ?>
                <div class="mws-form-message error">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='font-size:16px;list-style:none'><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- 右侧内容框架，更改从这里开始 -->
            <form action="/admins/group" method='post' class="mws-form">
                <?php echo e(csrf_field()); ?>

                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        用户组别
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_email" name="name" required lay-verify="name"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        升级费用
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="price" required lay-verify="required"
                        autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        阅读权限
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="weight" required lay-verify="required"
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                       *请填写1-10之间的数字
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        排序
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="sort" required lay-verify="required"
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                       *数字越小排名越靠前
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_sign" class="layui-form-label">
                    </label>
                    <button class="layui-btn" key="set-mine" lay-filter="save" lay-submit>
                        添加
                    </button>
                </div>
            </form>
            <!-- 右侧内容框架，更改从这里结束 -->
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lyout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>