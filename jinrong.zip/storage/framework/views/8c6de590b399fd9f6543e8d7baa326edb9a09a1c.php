<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
            <form action="/admin/notice/<?php echo e($res->id); ?>" method='post' class="mws-form">
                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        公告标题
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_email" name="title" required lay-verify="name" value="<?php echo e($res->title); ?>" 
                        autocomplete="off" class="layui-input" style="width: 600px">
                    </div>
                </div>
                 <div class="layui-form-item layui-form-text">
			    <label class="layui-form-label">公告内容</label>
			    <div class="layui-input-block">
			      <textarea placeholder="请输入公告内容" class="layui-textarea" name="content" style="width: 600px"><?php echo e($res->content); ?></textarea>
			    </div>
			  </div>

                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        排序
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_username" name="sort" required lay-verify="required" value="<?php echo e($res->sort); ?>" 
                        autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                       *数字越小排名越靠前
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_sign" class="layui-form-label">
                    </label>
                    
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                    <button class="layui-btn" key="set-mine" lay-filter="save" lay-submit>
                        修改
                    </button>
                </div>
            </form>
            <!-- 右侧内容框架，更改从这里结束 -->
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>