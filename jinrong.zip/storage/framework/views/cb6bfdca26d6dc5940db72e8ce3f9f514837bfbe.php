

<?php $__env->startSection('content'); ?>
	<div class="iheader scolld">
		<ul>
			<li>
					<a href="/">
						<div>
							<img src="/home/images/221152076509001026.jpg" />
							<span>新手指南</span>
						</div>
					</a>
				</li><li>
					<a href="/">
						<div>
							<img src="/home/images/195145834706008401.jpg" />
							<span>会员升级</span>
						</div>
					</a>
				</li><li>
					<a href="/">
						<div>
							<img src="/home/images/003904974817008437.jpg" />
							<span>号码检测</span>
						</div>
					</a>
				</li><li>
					<a href="/">
						<div>
							<img src="/home/images/210719215960005434.jpg" />
							<span>佣金列表</span>
						</div>
					</a>
				</li><li>
					<a href="/">
						<div>
							<img src="/home/images/225714550869008163.jpg" />
							<span>最新口子</span>
						</div>
					</a>
				</li>		</ul>
	</div>
	<div class="clearD"></div>
	<div class="inotice">
		<span class="volume"></span>
		<div class="intxt">
			<ul>
				<li><a href="/index.php?m=&c=Index&a=nInfo&id=12">新产品上架通知！！</a><em>2018-05-24</em></li>
				<li><a href="/index.php?m=&c=Index&a=nInfo&id=13">新手指南</a><em>2018-06-21</em></li>
				<li><a href="/index.php?m=&c=Index&a=nInfo&id=10">如遇app打不开，重新下载即可！！！</a><em>2018-05-19</em>
				</li>			
			</ul>
		</div>
	</div>
	
	<script>
		function ancs() {
			$(".intxt ul").animate({
				marginTop: "-28px"
			},
			600,
			function() {
				$(this).css({
					marginTop: "0px"
				}).find("li:first").appendTo(this);
			})
		}
		$(function() {
			var ans = setInterval("ancs()", 3000);
			$(".intxt").hover(function() {        
				clearInterval(ans);
			},
			function() {
				ans = setInterval("ancs()", 3000);
			})
		})
	</script>
	
	<div class="arsearch">
		<div>
			<span></span>
			<input id="keyword" type="text" value="" placeholder="请输入文章关键词搜索" />
			<button onclick="search();">搜索</button>
		</div>
	</div>
	<div class="arnav">
		<ul>
			<a href="/"><li class="" _acid="1">最新口子</li></a>
			<a href="/"><li class="" _acid="2">网贷攻略</li></a>
			<a href="/"><li class="" _acid="3">办卡提额</li></a>
		</ul>
	</div>
	<script>
		var acid = "1";
		$('.arnav ul li').each(function(){
			if($(this).attr("_acid") == acid){
				$(this).addClass('active');
			}
		})
		function search(){
			var keyword = $("#keyword").val();
			location.href="/index.php?m=&c=Index&a=index&acid="+acid+"&keyword="+keyword;
		}
	</script>
	<div class="icont">
		<ul>
			<li class="list-item">
					<a href="/" onclick="return checkUser();">
					<div class="txt">
						<img src="/uploads/100433990388001269.jpg" />
						<h1>宁波高炮新口子，芝麻分580以上就能贷，不看负面，最高5000元!</h1>
						<p><span>#最新口子</span>4小时前<em class="y">2997&nbsp;阅读</em></p>
					</div>
					</a>
				</li>
				<li class="list-item">
					<a href="/" onclick="return checkUser();">
					<div class="txt">
						<img src="/uploads/100433990388001269.jpg" />
						<h1>宁波高炮新口子，芝麻分580以上就能贷，不看负面，最高5000元!</h1>
						<p><span>#最新口子</span>4小时前<em class="y">2997&nbsp;阅读</em></p>
					</div>
					</a>
				</li>
				<li class="list-item">
					<a href="/" onclick="return checkUser();">
					<div class="txt">
						<img src="/uploads/100433990388001269.jpg" />
						<h1>宁波高炮新口子，芝麻分580以上就能贷，不看负面，最高5000元!</h1>
						<p><span>#最新口子</span>4小时前<em class="y">2997&nbsp;阅读</em></p>
					</div>
					</a>
				</li>
		</ul>	
	</div>
	
	<div class="levmsg" id="adInfo">
		<div class="msk"></div>
		<div class="lev">
			<div class="title">系统公告<span onclick="$('#adInfo').hide();">×</span></div>
				<div class="content">
					<p style="white-space: normal;"><strong>今日新上产品：号码检测<span style="color: rgb(0, 0, 0);"><span style="background-color: rgb(255, 255, 255);">，<strong style="font-size: 20px; white-space: normal;"><span style="font-size: 18px;"><span style="font-family: 宋体;">首次登陆号码检测免费赠送</span>50<span style="font-family: 宋体;">元代金券，若想免费检测，可以推荐好友关注金融行业公众号可随机获赠专属代金券，代金券可全额抵现金使用，上不封顶，如有疑问联系在线客服咨询。</span></span></strong></span></span></strong></p><p style="white-space: normal;"><img src="http://www.ppxlm666.com/Public/upload/image/20180620/1529482428232801.jpg" title="1529482428232801.jpg" alt="大佣金列表.jpg"/></p>				</div>
		</div>
	</div>
	<script>
		//首页如果带有广告参数则
		var ad = "1";
		if(ad == "1"){
			$('#adInfo .content').show();
			$('#adInfo').show();
		}
	
		//只有VIP等级用户查看
		function checkUser(){
			var level = "";
			var url = "/index.php?m=&c=Index&a=level";
			if(level == "0" || level == ""){
				salert("升级为会员才可以浏览本页面，请立即升级会员！",1,function(){location.href=url});
				return false;
			}
			return true;
		}
		
		$('.items').infiniteScroll({
			path: '.page .next',
			append: '.list-item',
			history: false,
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>