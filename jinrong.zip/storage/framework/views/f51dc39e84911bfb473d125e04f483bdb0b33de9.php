<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>金融管理系统</title>
  <link rel="stylesheet" href="/admins/layui/css/layui.css">
  <link rel="stylesheet" href="/admins/layui/css/base.css">
  <link rel="stylesheet" href="/admins/css/style.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/admins/layui/xadmin.js"></script>
  <script src="/admins/layui/layui.js"></script>
  <!-- 注意：如果你直接复制所有代码到本地，上述css路径需要改成你本地的 -->
</head>
<body>
  <div id="div_show">
<!-- 显示自动验证的错误信息 -->
<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
</body>
</html>