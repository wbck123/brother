<?php $__env->startSection('content'); ?>

<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                         <th>
                            新闻分类
                        </th>
                        <th>
                            新闻标题
                        </th>
                       
                        <th>
                            新闻封面
                        </th>
                        <th>
                            创建时间
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>

                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td >
                            <?php echo e($v->id); ?>

                        </td>
                        <td >
                            <?php echo e($v->title); ?>

                        </td>
                        
                        <td>
                            <?php echo e($v->sort); ?>

                        </td>
                        <th>
                            <img src="<?php echo e($v->pic); ?>" width="100px">
                        </th>
                        <th>
                           <?php
                              echo date('Y-m-d',$v->ctime);
                           ?>
                        </th>
                        <td>
                         <a href="/admin/article/<?php echo e($v->id); ?>/edit" class="layui-btn layui-btn-sm ">编辑</a>
                        <form action="/admin/article/<?php echo e($v->id); ?>" method='post' style='display:inline'>
                          <?php echo e(csrf_field()); ?>


                          <?php echo e(method_field('DELETE')); ?>

                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                    </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>