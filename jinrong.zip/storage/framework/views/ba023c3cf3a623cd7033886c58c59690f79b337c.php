<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            公告标题
                        </th>
                        <th>
                            排序
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td>
                            <?php echo e($res->id); ?>

                        </td>
                        <td>
                            <?php echo e($res->title); ?>

                        </td>
                        <td >
                            <?php echo e($res->sort); ?>

                        </td>
                    <td>
                         <a href="/admin/notice/<?php echo e($res->id); ?>/edit" class="layui-btn layui-btn-sm ">编辑</a>
                        <form action="/admin/notice/<?php echo e($res->id); ?>" method='post' style='display:inline'>
                          <?php echo e(csrf_field()); ?>


                          <?php echo e(method_field('DELETE')); ?>

                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
<!-- 右侧主体结束 -->
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>