<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>

<div class="admin-main layui-anim layui-anim-upbit">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">基础设置</li>
            <li>SEO管理</li>
            <li>其他</li>
        </ul>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <form class="layui-form layui-form-pane" lay-filter="form-system">
                    <div class="layui-form-item">
                        <label class="layui-form-label">网站名称</label>
                        <div class="layui-input-4">
                            <input type="text"name="name" lay-verify="required" placeholder="请输入网站名称" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">{:lang('WebsiteUrl')}</label>
                        <div class="layui-input-4">
                            <input type="text" name="url" lay-verify="url" placeholder="{:lang('pleaseEnter')}{:lang('WebsiteUrl')}" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">网站LOGO</label>
                        <input type="hidden" name="logo" id="logo">
                        <div class="layui-input-block">
                            <div class="layui-upload">
                                <button type="button" class="layui-btn layui-btn-primary" id="logoBtn"><i class="icon icon-upload3"></i>点击上传</button>
                                <div class="layui-upload-list">
                                    <img class="layui-upload-img" id="cltLogo">
                                    <p id="demoText"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">{:lang('recordNum')}</label>
                        <div class="layui-input-3">
                            <input type="text" name="bah" placeholder="{:lang('pleaseEnter')}{:lang('recordNum')}" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">Copyright</label>
                        <div class="layui-input-3">
                            <input type="text" name="copyright" placeholder="{:lang('pleaseEnter')}Copyright" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">{:lang('companyAddress')}</label>
                        <div class="layui-input-3">
                            <input type="text" name="ads" placeholder="{:lang('pleaseEnter')}{:lang('companyAddress')}" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">{:lang('tel')}</label>
                        <div class="layui-input-3">
                            <input type="text" name="tel" placeholder="{:lang('pleaseEnter')}{:lang('tel')}" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">{:lang('email')}</label>
                        <div class="layui-input-3">
                            <input type="text" name="email" placeholder="{:lang('pleaseEnter')}{:lang('email')}" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <div class="layui-input-block">
                            <button type="button" class="layui-btn" lay-submit="" lay-filter="sys">{:lang('submit')}</button>
                            <button type="reset" class="layui-btn layui-btn-primary">{:lang('reset')}</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="layui-tab-item">
                <form class="layui-form layui-form-pane" lay-filter="form-system">
                    <div class="layui-form-item">
                        <label class="layui-form-label">{:lang('seoTitle')}</label>
                        <div class="layui-input-4">
                            <input type="text"name="title" lay-verify="required" placeholder="{:lang('pleaseEnter')}{:lang('WebsiteUrl')}" class="layui-input">
                        </div>
                    </div>

                    <div class="layui-form-item layui-form-text">
                        <label class="layui-form-label">{:lang('seoKeyword')}</label>
                        <div class="layui-input-block">
                            <textarea name="key" lay-verify="required" placeholder="{:lang('pleaseEnter')}{:lang('seoKeyword')}" class="layui-textarea"></textarea>
                        </div>
                    </div>
                    <div class="layui-form-item layui-form-text">
                        <label class="layui-form-label">{:lang('description')}</label>
                        <div class="layui-input-block">
                            <textarea name="des" lay-verify="required" placeholder="{:lang('pleaseEnter')}{:lang('description')}" class="layui-textarea"></textarea>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <div class="layui-input-block">
                            <button type="button" class="layui-btn" lay-submit="" lay-filter="sys">{:lang('submit')}</button>
                            <button type="reset" class="layui-btn layui-btn-primary">{:lang('reset')}</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="layui-tab-item">
                <form class="layui-form layui-form-pane" lay-filter="form-system">
                    <div class="layui-form-item">
                        <label class="layui-form-label">手机端</label>
                        <div class="layui-input-block">
                            <input type="radio" name="mobile" value="open" title="开启">
                            <input type="radio" name="mobile" value="close" title="关闭">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">验证码</label>
                        <div class="layui-input-block">
                            <input type="radio" name="code" value="open" title="开启">
                            <input type="radio" name="code" value="close" title="关闭">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <div class="layui-input-block">
                            <button type="button" class="layui-btn" lay-submit="" lay-filter="sys">{:lang('submit')}</button>
                            <button type="reset" class="layui-btn layui-btn-primary">{:lang('reset')}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>