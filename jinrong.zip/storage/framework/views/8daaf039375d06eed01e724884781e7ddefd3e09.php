<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            银行名称
                        </th>
                        <th>
                            返佣价格
                        </th>
                        <th>
                            银行图片
                        </th>
                        <th>
                            排序
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td>
                            <?php echo e($res->id); ?>

                        </td>
                        <td>
                            <?php echo e($res->name); ?>

                        </td>
                        <td >
                            <?php echo e($res->price); ?>

                        </td>
                        <td >
                           <img src="<?php echo e($res->bpic); ?>" alt="" width="40px">
                        </td>
                        <td >
                            <?php echo e($res->sort); ?>

                        </td>
                    <td>
                       <a href="/admin/bank/<?php echo e($res->id); ?>/edit" class="layui-btn layui-btn-sm ">编辑</a>
                       <a href="javascript:void(0)" class="remove layui-btn layui-btn-sm layui-btn-danger" title="Remove this item" ids='<?php echo e($res->id); ?>'>删除</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>

layui.use(['jquery','layer'], function(){
    var $ = jQuery = layui.$;
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('.remove').click(function(){
        var id = $(this).attr('ids');
        layer.confirm('确定要删除吗?',{icon:3,title:'删除提示'},function(index){
               $.post('/admin/bankdel',{id:id},function(data){
                    if(data == '1'){
                        layer.msg('删除成功');
                        location.reload();
                    }else{
                        layer.msg('删除失败');
                    }
               })
        });
    })
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>