<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            用户级别
                        </th>
                        <th>
                            升级费用
                        </th>
                        <th>
                            阅读权重
                        </th>
                        <th>
                            排序
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td>
                            <?php echo e($res->id); ?>

                        </td>
                        <td>
                            <?php echo e($res->name); ?>

                        </td>
                        <td >
                            <?php echo e($res->price); ?>

                        </td>
                        <td >
                            <?php echo e($res->weight); ?>

                        </td>
                        <td >
                            <?php echo e($res->sort); ?>

                        </td>
                    <td>
                         <a href="/admin/group/<?php echo e($res->id); ?>/edit" class="layui-btn layui-btn-sm ">编辑</a>
                        <form action="/admin/group/<?php echo e($res->id); ?>" method='post' style='display:inline'>
                          <?php echo e(csrf_field()); ?>


                          <?php echo e(method_field('DELETE')); ?>

                          <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
<!-- 右侧主体结束 -->
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
   /*用户-添加*/
    function member_add(title,url,w,h)
    {
        x_admin_show(title,url,w,h);
    }
    /*用户-编辑*/
  function member_edit (title,url,id,w,h) 
  {
     x_admin_show(title,url,w,h); 
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>