<?php $__env->startSection('content'); ?>
<script type="text/javascript" charset="utf-8" src="/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/ueditor/lang/zh-cn/zh-cn.js"></script>

    <blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <?php if(count($errors) > 0): ?>
                <div class="mws-form-message error">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='font-size:16px;list-style:none'><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="/admin/article/<?php echo e($res->id); ?>" method='post' class="mws-form" enctype='multipart/form-data'>
                <?php echo e(csrf_field()); ?>


                <?php echo e(method_field('PUT')); ?>

                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        新闻分类
                    </label>
                   
                    <div class="layui-input-inline">
                        <select type="text" id="L_email" name="cid" required lay-verify="name"
                        autocomplete="off" class="layui-input">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k =>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <label for="L_email" class="layui-form-label">
                        新闻标题
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" id="L_email" name="title" required lay-verify="name"
                        autocomplete="off" class="layui-input" style="width:690px" value="<?php echo e($res->title); ?>">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        新闻封面
                    </label>
                    <div class="layui-input-inline">
                        <input type="file" name="pic" class="btn btn-default">
                    </div>
                </div>
                <script>
                    var ue = UE.getEditor('editor');
                </script>
                <div class="layui-form-item">
                    <label for="L_email" class="layui-form-label">
                        新闻内容
                    </label>
                    <div class="layui-input-inline">
                        <script id="editor" name='content' type="text/plain" style="width:1000px;height:500px;"></script>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label for="L_sign" class="layui-form-label">
                    </label>
                    <button class="layui-btn" key="set-mine" lay-filter="save" lay-submit>
                        修改
                    </button>
                </div>
            </form>
          </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>