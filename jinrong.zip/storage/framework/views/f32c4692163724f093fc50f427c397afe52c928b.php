<?php $__env->startSection('content'); ?>
    <script type="text/javascript" charset="utf-8" src="/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/ueditor/ueditor.all.min.js"> </script>
    <script type="text/javascript" charset="utf-8" src="/ueditor/lang/zh-cn/zh-cn.js"></script>

<blockquote class="layui-elem-quote f18"><?php echo e($res->title); ?><?php echo e($title); ?></blockquote>
            <form class="layui-form" action="/admin/service/<?php echo e($res->id); ?>" enctype='multipart/form-data' method='post'>

                <?php echo e(csrf_field()); ?>


                <?php echo e(method_field('PUT')); ?>


                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        协议标题
                    </label>
                    <div class="layui-input-block">
                        <input type="text" id="L_username" name="name" value="<?php echo e($res->title); ?>" class="layui-input" disabled>
                    </div>
                </div>
                <script>
                    var ue = UE.getEditor('editor');
                </script>

                <div class="layui-form-item">
                    <label for="L_username" class="layui-form-label">
                        协议内容
                    </label>
                    <div class="layui-input-block">
                        <script id="editor" name='content' type="text/plain" style="width:1000px;height:500px;"><?php echo e($res->content); ?></script>
                    </div>
                </div>
                
            </div>
                <div class="layui-form-item">
                    <label for="L_repass" class="layui-form-label">
                    </label>
                    <button  class="layui-btn" lay-filter="save" lay-submit="">
                        修改
                    </button>
                </div>
            </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>