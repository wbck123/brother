<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
        <div class="page-content">
          <div class="content">
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            记录ID
                        </th>
                        <th>
                            协议标题
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td>
                            <?php echo e($res->id); ?>

                        </td>
                        <td>
                            <?php echo e($res->title); ?>

                        </td>
                    <td>
                         <a href="/admin/service/<?php echo e($res->id); ?>/edit" class="layui-btn layui-btn-sm ">修改</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
<!-- 右侧主体结束 -->
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>