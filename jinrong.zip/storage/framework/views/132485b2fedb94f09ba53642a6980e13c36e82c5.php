<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>

<form class="layui-form" action="">
  <div class="layui-form-item">
    <label class="layui-form-label">网站标题</label>
    <div class="layui-input-block">
      <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入网站标题" value="<?php echo e($res->name); ?>" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">网站关键字</label>
    <div class="layui-input-block">
      <input type="text" name="username" lay-verify="required" placeholder="请输入SEO关键字" autocomplete="off" class="layui-input">
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label">网站描述</label>
    <div class="layui-input-block">
      <input type="text" name="username" lay-verify="required" placeholder="请输入网站描述" autocomplete="off" class="layui-input">
    </div>
  </div>
 

    <div class="layui-form-item">
    <div class="layui-inline">
      <label class="layui-form-label">微信公众号</label>
      <div class="layui-input-inline">
        <input type="tel" name="phone" lay-verify="required|phone" autocomplete="off" class="layui-input">
      </div>
    </div>

    <div class="layui-inline">
      <label class="layui-form-label">联系电话</label>
      <div class="layui-input-inline">
        <input type="tel" name="phone" lay-verify="required|phone" autocomplete="off" class="layui-input">
      </div>
    </div>

    <div class="layui-inline">
      <label class="layui-form-label">备案编号</label>
      <div class="layui-input-inline">
        <input type="text" name="email" lay-verify="email" autocomplete="off" class="layui-input">
      </div>
    </div>
  </div>
  
  <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">统计代码</label>
    <div class="layui-input-block">
      <textarea placeholder="请输入内容" class="layui-textarea w515"></textarea>
    </div>
  </div>
  
  <div class="layui-form-item">
    <button class="layui-btn" lay-submit="" lay-filter="demo2">保存信息</button>
  </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>