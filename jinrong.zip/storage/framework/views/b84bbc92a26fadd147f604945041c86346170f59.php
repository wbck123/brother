<?php $__env->startSection('content'); ?>


        <div class="page-content">
          <div class="content">
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>
            <table class="layui-table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            新闻标题
                        </th>
                        <th>
                            新闻分类
                        </th>
                        <th>
                            新闻内容
                        </th>
                        <th>
                            新闻封面
                        </th>
                        <th>
                            创建时间
                        </th>
                        <th>
                            操作
                        </th>
                    </tr>

                </thead>
                <tbody>
                    <tr>
                        <td >
                            1
                        </td>
                        <td >
                            1
                        </td>
                        <td>
                            1
                        </td>
                        <td >
                            1
                        </td>
                        <th>
                            1
                        </th>
                        <th>
                            1
                        </th>
                        <td class="td-manage">
                            <form action="/admin/artice/" method='post' style='display:inline'>
                                <?php echo e(csrf_field()); ?>


                                <?php echo e(method_field('DELETE')); ?>

                                <button class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                            </form>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- 右侧内容框架，更改从这里结束 -->
          </div>
        </div>
        <!-- 右侧主体结束 -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>