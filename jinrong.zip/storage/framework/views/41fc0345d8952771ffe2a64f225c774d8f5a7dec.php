<?php $__env->startSection('content'); ?>
<blockquote class="layui-elem-quote f18"><?php echo e($title); ?></blockquote>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>